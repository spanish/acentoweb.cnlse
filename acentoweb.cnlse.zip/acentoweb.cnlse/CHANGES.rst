Changelog
=========


1.0a1 (unreleased)
------------------

- Initial release.
  [espenmn]


1.0a2 (unreleased)
------------------

- Second release.
  [acentoweb]
